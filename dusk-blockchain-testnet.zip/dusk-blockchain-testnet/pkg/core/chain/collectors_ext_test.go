package chain_test

import "testing"

func TestTxCollection(t *testing.T) {

}
