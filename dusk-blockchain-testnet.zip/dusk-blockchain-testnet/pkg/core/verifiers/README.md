This package is intended to provide a stateless and standalone execution of a complete and partly verifications of a chain block and all types of chain transactions. It might be extended soon into a utility that can create and sign all types of transactions.

Exposed API

- CheckBlock
- CheckTx