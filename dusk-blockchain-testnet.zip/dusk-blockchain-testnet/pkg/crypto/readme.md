## Package Crypto

### Purpose

This package will be used to stre generic cryptographic schemes, such as sha3, checksum and random entropy. 
This is different to cryptographic schemes such as bulletproof and vrf which have one or two specific usecases in the repo.