package database

func encrypt(data []byte, passphrase []byte) ([]byte, error) {
	return data, nil
}

func decrypt(data []byte, passphrase []byte) ([]byte, error) {
	return data, nil
}
